//
//  AppDelegate.h
//  20170425HelloMyAVPlayer
//
//  Created by user35 on 2017/4/25.
//  Copyright © 2017年 user35. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

