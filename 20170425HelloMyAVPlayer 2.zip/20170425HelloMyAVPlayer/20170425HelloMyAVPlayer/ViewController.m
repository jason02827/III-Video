//
//  ViewController.m
//  20170425HelloMyAVPlayer
//
//  Created by user35 on 2017/4/25.
//  Copyright © 2017年 user35. All rights reserved.
//

#import "ViewController.h"
#import <AVKit/AVKit.h>
#import <AVFoundation/AVFoundation.h>

@interface ViewController ()
{
    AVPlayer *player;
    AVPlayerLayer *playerLayer;
}
@property (weak, nonatomic) IBOutlet UIImageView *resultImageView;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender{
    
    if ([segue.identifier isEqualToString:@"goFullScreen"]) {//檢查是哪個segue
        
        [self stopBtnPressed:nil];//Stop current playing
         NSURL *url = [NSURL URLWithString:@"http://184.72.239.149/vod/smil:bigbuckbunnyiphone.smil/playlist.m3u8"];
        AVPlayerViewController *vc = segue.destinationViewController;
        vc.player = [[AVPlayer alloc]initWithURL:url];
        [vc.player play];
    }
}

- (IBAction)playRemoteMovieBtnPressed:(id)sender {
    NSURL *url = [NSURL URLWithString:@"http://184.72.239.149/vod/smil:bigbuckbunnyiphone.smil/playlist.m3u8"];  //m3u8是HLS:HTTP Live Streaming。直播設計使用，畫質自動依頻寬調整//舊的是RTSP or RTMP不好用
    [self playWithURL:url];
}

- (IBAction)playLocalMovieBtnPressed:(id)sender {
    
    NSURL *url = [[NSBundle mainBundle]URLForResource:@"stevejobs_memorial_us.mp4" withExtension:nil];
    [self playWithURL:url];
}

- (IBAction)playRemoteMP3BtnPressed:(id)sender {
}

- (IBAction)getThumbnailBtnPressed:(id)sender {
    NSURL *url = [[NSBundle mainBundle]URLForResource:@"stevejobs_memorial_us.mp4" withExtension:nil];
    AVURLAsset *asset = [AVURLAsset URLAssetWithURL:url options:nil];//路徑轉格式
    AVAssetImageGenerator *generator = [AVAssetImageGenerator assetImageGeneratorWithAsset:asset];
    generator.appliesPreferredTrackTransform = true;//true參考影片拍攝時的方向來產生縮圖
    generator.requestedTimeToleranceAfter = kCMTimeZero;//盡量準確找到該格圖片
    generator.requestedTimeToleranceBefore = kCMTimeZero;//盡量準確找到該格圖片
    CMTime time = CMTimeMake(3, 10);//圖片從影片的時間產生，假設1秒鐘10張圖取第3張，比用秒數精準，每秒幾張是開發者自己假設
    CGImageRef cgImage = [generator copyCGImageAtTime:time actualTime:nil error:nil];//從該時間產出圖片
    UIImage *image = [UIImage imageWithCGImage:cgImage]; //轉圖片格式
    _resultImageView.image = image;
    CGImageRelease(cgImage);//Important 釋放
}
- (IBAction)fullScreenPlaybackBtnPressed:(id)sender {
    
    
}
- (IBAction)stopBtnPressed:(id)sender {
    if (player == nil) {
        return;
    }
    player.rate = 0.0; //0.0:stop , 0.5:Half Speed , 2.0:Double Speed
//    [player pause]; //暫停，內建沒有停止
    
    [playerLayer removeFromSuperlayer]; //Important! 要主動釋放
    player = nil;
    playerLayer = nil;
    
    //加入監聽Add observer for playbackDidFinish
    [[NSNotificationCenter defaultCenter] removeObserver:self name:AVPlayerItemDidPlayToEndTimeNotification object:nil];
}

-(void)playWithURL:(NSURL *)url{
    [self stopBtnPressed:nil]; //避免多個播放同時啟用Stop previous one if exist
    AVPlayerItem *item = [AVPlayerItem playerItemWithURL:url];
    player = [[AVPlayer alloc] initWithPlayerItem:item];
    playerLayer = [AVPlayerLayer playerLayerWithPlayer:player]; //畫面顯示區域
    playerLayer.frame  = _resultImageView.frame;
    [self.view.layer addSublayer:playerLayer];
    [player play];
    player.rate = 1.0; //1.0是用標準速度播放，遠端影片可能無效
    
    //加入監聽Add observer for playbackDidFinish
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(playbackDidFinish) name:AVPlayerItemDidPlayToEndTimeNotification object:nil];
}

-(void) playbackDidFinish{  //播放結束時會被呼叫
    [self stopBtnPressed:nil];  //實際專案可增加其他變化
}

@end







