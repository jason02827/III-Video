//
//  main.m
//  20170425HelloMyAVPlayer
//
//  Created by user35 on 2017/4/25.
//  Copyright © 2017年 user35. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
